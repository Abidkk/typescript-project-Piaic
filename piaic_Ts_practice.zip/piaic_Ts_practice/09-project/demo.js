var favoriteNumber = 45;
var message = "".concat(favoriteNumber, " is my favourite number");
console.log(message);
