/* Ali abid : Date: 10-02-2023 
storing favorite number wirh message
*/


let favoriteNumber = 45;
let message = `${favoriteNumber} is my favourite number`;
console.log(message);
