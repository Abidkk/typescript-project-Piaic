///   creating Array error .
// this is an String Array
// var Array1 :string[] = ["Karachi","Islamabad","Lahore",5000,"Quetta","Mirpurkhas"];  
//console.log(Array1)
//  There was an error on index 3 because we can't store number in string Array type;
// resolving error below:
var Arra1 = ["Karachi", "Islamabad", "Lahore", "Sukkur", "Quetta", "Mirpurkhas"];
console.log(Arra1);
