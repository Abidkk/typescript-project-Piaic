function makeSandwich(...ingredients: string[]) {
    console.log("Making a sandwich with the following ingredients: " + ingredients.join(", "));
  }
  
  makeSandwich("bread", "lettuce", "tomato", "mayonnaise");
  makeSandwich("bread", "cheese", "ham");
  makeSandwich("bread", "peanut butter", "jelly");