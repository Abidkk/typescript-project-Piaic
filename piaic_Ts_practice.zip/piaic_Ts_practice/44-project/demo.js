function makeSandwich() {
    var ingredients = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        ingredients[_i] = arguments[_i];
    }
    console.log("Making a sandwich with the following ingredients: " + ingredients.join(", "));
}
makeSandwich("bread", "lettuce", "tomato", "mayonnaise");
makeSandwich("bread", "cheese", "ham");
makeSandwich("bread", "peanut butter", "jelly");
