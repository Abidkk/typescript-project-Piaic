


let currentUsers: string[] = ["John", "Jane", "Jim", "Jenny", "Jake"];
let newUsers: string[] = ["john", "jimmy", "jane", "jessica", "jared"];

for (let newUser of newUsers) {
  let isUnique = true;
  for (let currentUser of currentUsers) {
    if (newUser.toLowerCase() === currentUser.toLowerCase()) {
      console.log(`Sorry, the username "${newUser}" is already taken. Please enter a new username.`);
      isUnique = false;
      break;
    }
  }
  if (isUnique) {
    console.log(`The username "${newUser}" is available.`);
  }
}