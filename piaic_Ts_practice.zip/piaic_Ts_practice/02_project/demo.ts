/* Ali abid : Date: 10-02-2023 
printing a message to sir zia
*/



let name = "Sir Zia";
console.log(`"Hello" ${name} would you like to teach us Blockchain ?`)
