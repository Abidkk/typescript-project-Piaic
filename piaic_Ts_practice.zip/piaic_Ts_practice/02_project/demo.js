var name = "Sir Zia";
console.log("\"Hello\" ".concat(name, " would you like to teach us Blockchain ?"));
