let magicians: string[] = ['Nomi', 'Shani', 'Romeo'];

function make_great(magicians: string[]): string[] {
    let greatMagicians: string[] = [];
    for (let i = 0; i < magicians.length; i++) {
        greatMagicians.push('The Great ' + magicians[i]);
    }
    return greatMagicians;
}

let originalMagicians = magicians.slice();
let greatMagicians = make_great(magicians);

function show_magicians(magicians: string[]): void {
    for (let magician of magicians) {
        console.log(magician);
    }
}

console.log('Original Magicians:');
show_magicians(originalMagicians);
console.log('\nGreat Magicians:');
show_magicians(greatMagicians);