var magicians = ['Nomi', 'Shani', 'Romeo'];
function make_great(magicians) {
    var greatMagicians = [];
    for (var i = 0; i < magicians.length; i++) {
        greatMagicians.push('The Great ' + magicians[i]);
    }
    return greatMagicians;
}
var originalMagicians = magicians.slice();
var greatMagicians = make_great(magicians);
function show_magicians(magicians) {
    for (var _i = 0, magicians_1 = magicians; _i < magicians_1.length; _i++) {
        var magician = magicians_1[_i];
        console.log(magician);
    }
}
console.log('Original Magicians:');
show_magicians(originalMagicians);
console.log('\nGreat Magicians:');
show_magicians(greatMagicians);
