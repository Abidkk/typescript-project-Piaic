function makeShirt(size: string = "Large", message: string = "I love TypeScript"): void {
    console.log(`The shirt is size ${size} and has the message "${message}" printed on it.`);
  }
  
  makeShirt(); // Large, I love TypeScript
  makeShirt("Medium"); // Medium, I love TypeScript
  makeShirt("Small", "TypeScript is awesome"); // Small, TypeScript is awesome