/// Stages of Life :   

var personAge = 1;

if (personAge < 2 ) {
    console.log("The person is a baby")
} else if (personAge == 2 || personAge < 4 ){
    console.log("The person is a toddler")
}else if (personAge == 4 || personAge < 13 ){
    console.log("The person is a kid")
}else if (personAge == 13 || personAge < 20 ){
    console.log("The person is a teenager")
}else if (personAge == 20 || personAge < 65 ){
    console.log("The person is an Adult")
}else{
    console.log("The person is an elder")
}
///  
  
//  2nd contidion is True
var personAge = 3;

if (personAge < 2 ) {
    console.log("The person is a baby")
} else if (personAge == 2 || personAge < 4 ){
    console.log("The person is a toddler")
}else if (personAge == 4 || personAge < 13 ){
    console.log("The person is a kid")
}else if (personAge == 13 || personAge < 20 ){
    console.log("The person is a teenager")
}else if (personAge == 20 || personAge < 65 ){
    console.log("The person is an Adult")
}else{
    console.log("The person is an elder")
}


//  3rd  contidion is True
var personAge = 10;

if (personAge < 2 ) {
    console.log("The person is a baby")
} else if (personAge == 2 || personAge < 4 ){
    console.log("The person is a toddler")
}else if (personAge == 4 || personAge < 13 ){
    console.log("The person is a kid")
}else if (personAge == 13 || personAge < 20 ){
    console.log("The person is a teenager")
}else if (personAge == 20 || personAge < 65 ){
    console.log("The person is an Adult")
}else{
    console.log("The person is an elder")
}



//  4th  contidion is True
var personAge = 19;

if (personAge < 2 ) {
    console.log("The person is a baby")
} else if (personAge == 2 || personAge < 4 ){
    console.log("The person is a toddler")
}else if (personAge == 4 || personAge < 13 ){
    console.log("The person is a kid")
}else if (personAge == 13 || personAge < 20 ){
    console.log("The person is a teenager")
}else if (personAge == 20 || personAge < 65 ){
    console.log("The person is an Adult")
}else{
    console.log("The person is an elder")
}




// 5th  contidion is True
var personAge = 20;

if (personAge < 2 ) {
    console.log("The person is a baby")
} else if (personAge == 2 || personAge < 4 ){
    console.log("The person is a toddler")
}else if (personAge == 4 || personAge < 13 ){
    console.log("The person is a kid")
}else if (personAge == 13 || personAge < 20 ){
    console.log("The person is a teenager")
}else if (personAge == 20 || personAge < 65 ){
    console.log("The person is an Adult")
}else{
    console.log("The person is an elder")
}



//  6th  contidion is True
var personAge = 65;

if (personAge < 2 ) {
    console.log("The person is a baby")
} else if (personAge == 2 || personAge < 4 ){
    console.log("The person is a toddler")
}else if (personAge == 4 || personAge < 13 ){
    console.log("The person is a kid")
}else if (personAge == 13 || personAge < 20 ){
    console.log("The person is a teenager")
}else if (personAge == 20 || personAge < 65 ){
    console.log("The person is an Adult")
}else{
    console.log("The person is an elder")
}





