
/* Ali abid : Date: 10-02-2023 
printing a name with whitespaces and  without whitespaces*/

var personName = "   Tanveer   ";
console.log(personName);
personName="Tanveer";
console.log(personName)
