var personName = "   Tanveer   ";
console.log(personName);
personName = "Tanveer";
console.log(personName);
