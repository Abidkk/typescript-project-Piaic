// Excersice 31
var user = ["Bilal", "Ahmed", "Sohail", "Imran"];
var user = [];
if (user.length === 0) {
    console.log("We need to find some users!");
}
