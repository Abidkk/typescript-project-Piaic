let pizzas: string[] = ["Pepperoni", "Margherita", "Hawaiian"];

for (let pizza of pizzas) {
  console.log(`I like ${pizza} pizza.`);
}

console.log("I really love pizza!");