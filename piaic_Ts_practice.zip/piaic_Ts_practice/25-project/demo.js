// Alien Game
var alien_color = "green";
if (alien_color == "green") {
    console.log("The player earned 5 points");
}
/////  
if (alien_color == "red") {
    // it fails having no output
}
else {
    console.log("Yes it is green");
}
