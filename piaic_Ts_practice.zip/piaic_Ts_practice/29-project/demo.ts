// Favourite fruit project :




var favorite_fruit: string[] = ["Apple","Banana","Grapes"];

//  -- Fruit 1
var fruit1 = favorite_fruit.find(search);
function search(Apple){
    return Apple == 'Apple'
}
///console.log(fruit)   // Yes, found it

if (fruit1 == "Apple"){
    console.log("Oh, You really like Apples")
}
  

/// Fruit 2
var fruit2 = favorite_fruit.find(search2);
function search2(Banana){
    return Banana == 'Banana'
}
///console.log(fruit)   // Yes, found it

if (fruit2 == "Banana"){
    console.log("Oh, You really like Banana")
}


// Fruit 3
var fruit3 = favorite_fruit.find(search3);
function search3(Grapes){
    return Grapes == 'Grapes'
}
///console.log(fruit)   // Yes, found it

if (fruit3 == "Grapes"){
    console.log("Oh, You really like Grapes")
}


/// Fruit 4 // not here
var fruit4 = favorite_fruit.find(search4);
function search4(Guava){
    return Guava == 'Guava'
}
///console.log(fruit)   // Yes, found it

if (fruit4 == "Guava"){
    console.log("Oh, You really like Guava")
}


/// Fruit 4 // not here
var fruit4 = favorite_fruit.find(search4);
function search4(Guava){
    return Guava == 'Guava'
}
///console.log(fruit)   // Yes, found it

if (fruit4 == "Guava"){
    console.log("Oh, You really like Guava")
}



/// Fruit 5 // not here
var fruit5 = favorite_fruit.find(search5);
function search5(Guava){
    return Guava == 'Peach'
}
///console.log(fruit)   // Yes, found it

if (fruit5 == "Peach"){
    console.log("Oh, You really like Guava")
}



