// creating an Array and getting value one by one with concating a message to each person
var names = ["Sohail", "Zahid", "Bilal", "Adnan", "Noman"];
var greet = "How are you doing today?";
console.log(names[0] + " " + greet);
console.log(names[1] + " " + greet);
console.log(names[2] + " " + greet);
console.log(names[3] + " " + greet);
console.log(names[4] + " " + greet);
