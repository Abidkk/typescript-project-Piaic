// list of countries

let countries = ["{Pakistan","India","China","Afghanistan","Turkeye","Germany","Japan","Indonasia","Italy"];
console.log(countries);