// list of countries
var countries = ["{Pakistan", "India", "China", "Afghanistan", "Turkeye", "Germany", "Japan", "Indonasia", "Italy"];
console.log(countries);
