//  Inviting Guests for dinner on my Birthday party .
var guests = ["Sohail", "Amir", "Bilal"];
///let message = "Hello dear name is my birthday on comming sunday So are invited as a special guest."
console.log("Hello dear ".concat(guests[0], ", my birthday is comming on sunday  So are invited as a special guest. Thanks!"));
console.log("Hello dear ".concat(guests[1], ", my birthday is comming on sunday  So are invited as a special guest. Thanks!"));
console.log("Hello dear ".concat(guests[2], ", my birthday is comming on sunday  So are invited as a special guest. Thanks!"));
console.log("Mr Bilal can't cook so I am removing him");
guests.pop();
console.log("I am adding a new guest named Imran who is  replacing Bilal");
guests.push("Imran");
console.log("Hello dear ".concat(guests[0], ", my birthday is comming on sunday  So are invited as a special guest. Thanks!"));
console.log("Hello dear ".concat(guests[1], ", my birthday is comming on sunday  So are invited as a special guest. Thanks!"));
console.log("Hello dear ".concat(guests[2], ", my birthday is comming on sunday  So are invited as a special guest. Thanks!"));
