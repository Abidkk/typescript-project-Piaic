
/* Ali abid : Date: 10-02-2023 
storing author name and concating his quote in single variable
*/

var famous_person = "Once Abdul Qalam said,";
var message = `${famous_person} "The best brain of the nation may by found in the last banches of the classroom"`;
console.log(message)