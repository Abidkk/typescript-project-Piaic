var famous_person = "Once Abdul Qalam said,";
var message = "".concat(famous_person, " \"The best brain of the nation may by found in the last banches of the classroom\"");
console.log(message);
