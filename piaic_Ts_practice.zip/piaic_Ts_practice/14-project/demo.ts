//  Inviting Guests for dinner on my Birthday party .


let guests =["Sohail","Amir","Bilal"];
let message = "Hello dear name is my birthday on comming sunday So are invited as a special guest."
console.log(`Hello dear ${guests[0]}, my birthday is comming on sunday  So are invited as a special guest. Thanks!`)
console.log(`Hello dear ${guests[1]}, my birthday is comming on sunday  So are invited as a special guest. Thanks!`)
console.log(`Hello dear ${guests[2]}, my birthday is comming on sunday  So are invited as a special guest. Thanks!`)