let name = "ali AbID";

console.log(name.toLowerCase());
console.log(name.toUpperCase());
//console.log(name.toLocaleUpperCase());
let titleCased = name.split(" ").map(word => {
  return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
}).join(" ");
console.log(titleCased); 