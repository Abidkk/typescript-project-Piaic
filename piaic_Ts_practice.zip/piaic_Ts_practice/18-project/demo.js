// Array of locations
var locations = ["Dubai", "Switzerland", "Makkah & Madina", "Tokyo", "Germany"];
// printing Array in original form
console.log(locations);
// printing in Alphabatical order 
console.log(locations.sort());
console.log("".concat(locations, " No it is not in its original order"));
//  printing in reverse order
console.log(locations.reverse());
console.log("".concat(locations, " No Again it is not in its original order"));
console.log(locations.reverse());
console.log(locations.reverse());
// sorting 
console.log(locations.sort());
