/// Alien Game 2 
var alien_color = "red";
if (alien_color == "green") {
    console.log("the player just earned 5 points for shooting the alien.");
}
else if (alien_color !== "green") {
    console.log("the player just earned 10 points for shooting the alien");
}
// Another version of this programe with if and else
if (alien_color == "green") {
    console.log("the player just earned 5 points for shooting the alien.");
}
else {
    console.log("the player just earned 10 points for shooting the alien");
}
