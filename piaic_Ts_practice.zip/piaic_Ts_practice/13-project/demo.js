// Creating an Array of FavTransport and using each with different statement.  
var favTransport = ["car", "train", "motorbike", "Aeroplane."];
console.log("I like to ride on a ".concat(favTransport[0], ", when there is no traffic on the road."));
console.log("when there is traffic on the road, I use ".concat(favTransport[2]));
console.log("".concat(favTransport[1], " with friends having fun."));
console.log("We will go to madina in Dec 2023 via ".concat(favTransport[3]));
