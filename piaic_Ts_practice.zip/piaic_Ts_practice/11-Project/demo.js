// creating an Array and getting value one by one  
var names = ["Sohail", "Zahid", "Bilal", "Adnan", "Noman"];
console.log(names[0]);
console.log(names[1]);
console.log(names[2]);
console.log(names[3]);
console.log(names[4]);
