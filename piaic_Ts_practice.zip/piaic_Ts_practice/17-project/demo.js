//  Inviting Guests for dinner on my Birthday party .
var guests = ["Sohail", "Amir", "Bilal"];
///let message = "Hello dear name is my birthday on comming sunday So are invited as a special guest."
console.log("Hello dear ".concat(guests[0], ", my birthday is comming on sunday  So are invited as a special guest. Thanks!"));
console.log("Hello dear ".concat(guests[1], ", my birthday is comming on sunday  So are invited as a special guest. Thanks!"));
console.log("Hello dear ".concat(guests[2], ", my birthday is comming on sunday  So are invited as a special guest. Thanks!"));
console.log("Mr Bilal can't cook so I am removing him");
guests.pop(); //  remiving guest
console.log("I am adding a new guest named Imran who is  replacing Bilal");
guests.push("Imran"); // adding new guest
console.log("Hello dear ".concat(guests[0], ", my birthday is comming on sunday  So are invited as a special guest. Thanks!"));
console.log("Hello dear ".concat(guests[1], ", my birthday is comming on sunday  So are invited as a special guest. Thanks!"));
console.log("Hello dear ".concat(guests[2], ", my birthday is comming on sunday  So are invited as a special guest. Thanks!"));
///  Calling more guests
console.log("Now I found more place on dinner Table so I am going to call more guests");
/// Adding new guest name Zahid at the begining of the Array;
guests.unshift("Zahid");
console.log(guests);
/// Adding new guest name Shahzaib in the middle  of the Array;
guests.splice(2, 0, "Shahzaib");
console.log(guests);
/// Adding new guest name Nasir at the end  of the Array;
guests.push("Nasir");
console.log(guests);
console.log("Hello dear ".concat(guests[0], ", my birthday is comming on sunday  So you are invited as a special guest. Thanks!"));
console.log("Hello dear ".concat(guests[1], ", my birthday is comming on sunday  So you are invited as a special guest. Thanks!"));
console.log("Hello dear ".concat(guests[2], ", my birthday is comming on sunday  So you are invited as a special guest. Thanks!"));
console.log("Hello dear ".concat(guests[4], ", my birthday is comming on sunday  So you are invited as a special guest. Thanks!"));
console.log("Hello dear ".concat(guests[5], ", my birthday is comming on sunday  So you are invited as a special guest. Thanks!"));
console.log("Sorry now I can invite only two people for dinner");
var pop1 = guests.pop();
console.log("Sorry ".concat(pop1, " I can't invite you for dinner"));
var pop2 = guests.pop();
console.log("Sorry ".concat(pop2, " I can't invite you for dinner"));
var pop3 = guests.pop();
console.log("Sorry ".concat(pop3, " I can't invite you for dinner"));
var pop4 = guests.pop();
console.log("Sorry ".concat(pop4, " I can't invite you for dinner"));
var still = "You are still invited";
console.log("Hello dear ".concat(guests[0], ", ").concat(still));
console.log("Hello dear ".concat(guests[1], ", ").concat(still));
// Removing last two members from Array so Array will be Empty
console.log(guests);
guests.splice(0, 2); // deleting last members 
console.log(guests);
