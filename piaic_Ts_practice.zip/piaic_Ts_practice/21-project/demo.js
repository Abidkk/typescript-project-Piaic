// Typescript object // Countries name
var countries = {
    c1: "Pakistan",
    c2: "China",
    c3: "Indonasia",
    c4: "India",
    c5: "Brazil",
    c6: "Poland",
    c7: "Germany",
    c8: "Thailand",
    c9: "Sweden",
    c10: "UAE"
};
console.log(countries);
