/// invitiing only two guests for dinner
console.log("I am inviting only two guests for dinner");
