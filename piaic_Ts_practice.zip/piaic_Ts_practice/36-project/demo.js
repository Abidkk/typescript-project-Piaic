function makeShirt(size, message) {
    console.log("The shirt is size ".concat(size, " and has the message \"").concat(message, "\" printed on it."));
}
makeShirt("Large", "I love TypeScript");
