function makeShirt(size: string, message: string): void {
    console.log(`The shirt is size ${size} and has the message "${message}" printed on it.`);
  }
  
  makeShirt("Large", "I love TypeScript");