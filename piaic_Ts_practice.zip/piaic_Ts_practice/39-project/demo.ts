function cityCountry(city: string, country: string): string {
    return `${city}, ${country}`;
  }
  
  const city1 = cityCountry("Lahore", "Pakistan");
  const city2 = cityCountry("London", "United Kingdom");
  const city3 = cityCountry("New York", "USA");
  
  console.log(city1); // Lahore, Pakistan
  console.log(city2); // London, United Kingdom
  console.log(city3); // New York, USA