function cityCountry(city, country) {
    return "".concat(city, ", ").concat(country);
}
var city1 = cityCountry("Lahore", "Pakistan");
var city2 = cityCountry("London", "United Kingdom");
var city3 = cityCountry("New York", "USA");
console.log(city1); // Lahore, Pakistan
console.log(city2); // London, United Kingdom
console.log(city3); // New York, USA
