
/* Ali abid : Date: 10-02-2023 
using Arithmetoc operators ( Addition, Subtraction, Multiplication and Division)
*/

console.log(2+6);
console.log(10-2);
console.log(4*2);
console.log(24/3);


