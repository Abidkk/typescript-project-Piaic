const magicians: string[] = ['Shani', 'Nomi', 'Romeo'];

function showMagicians(names: string[]): void {
  for (const name of names) {
    console.log(name);
  }
}

showMagicians(magicians);