/* Ali abid : Date: 10-02-2023 
Printing a famous person Quote with author :
*/


console.log(`Darren Hardy wrote in his book "The Compound Effect"."You make your choices, and than your choices make you."`)