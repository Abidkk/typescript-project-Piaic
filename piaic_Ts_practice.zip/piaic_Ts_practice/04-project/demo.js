console.log("Darren Hardy wrote in his book \"The Compound Effect\".\"You make your choices, and than your choices make you.\"");
