let magicians: string[] = ["Nomi", "Shani", "Romeo"];

function showMagicians(magicians: string[]): void {
    for (let magician of magicians) {
        console.log(magician);
    }
}

function makeGreat(magicians: string[]): void {
    for (let i = 0; i < magicians.length; i++) {
        magicians[i] = "The Great " + magicians[i];
    }
}

makeGreat(magicians);
showMagicians(magicians);