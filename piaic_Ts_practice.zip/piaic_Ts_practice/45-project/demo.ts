function carDetails(manufacturer: string, model: string, ...options: any[]) {
    let car = {
      Manufacturer: manufacturer,
      Model: model,
    };
  
    for (let i = 0; i < options.length; i+=2) {
      car[options[i]] = options[i+1];
    }
  
    return car;
  }
  
  let car1 = carDetails("Toyota", "Camry", "Color", "Red", "Features", "Sunroof, Blind Spot Monitoring");
  let car2 = carDetails("Tesla", "Model 3", "Color", "Blue", "Features", "Autopilot, Ludicrous Mode");
  
  console.log(car1);
  console.log(car2);