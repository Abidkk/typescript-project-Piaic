function carDetails(manufacturer, model) {
    var options = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        options[_i - 2] = arguments[_i];
    }
    var car = {
        Manufacturer: manufacturer,
        Model: model
    };
    for (var i = 0; i < options.length; i += 2) {
        car[options[i]] = options[i + 1];
    }
    return car;
}
var car1 = carDetails("Toyota", "Camry", "Color", "Red", "Features", "Sunroof, Blind Spot Monitoring");
var car2 = carDetails("Tesla", "Model 3", "Color", "Blue", "Features", "Autopilot, Ludicrous Mode");
console.log(car1);
console.log(car2);
