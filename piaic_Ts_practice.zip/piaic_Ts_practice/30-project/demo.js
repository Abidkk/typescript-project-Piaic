//  Hello Admin Project  :
var users = ['Admin', 'Imran', 'Sohail', 'Zahid', 'Bilal'];
for (var _i = 0, users_1 = users; _i < users_1.length; _i++) {
    var userName = users_1[_i];
    if (userName === "Admin") {
        console.log("Hello ".concat(userName, ", would you like to see a status report?"));
    }
    else {
        console.log("Hello ".concat(userName, ", thank you for logging in again."));
    }
}
