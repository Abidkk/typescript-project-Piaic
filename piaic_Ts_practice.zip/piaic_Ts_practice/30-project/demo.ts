//  Hello Admin Project  :

var users = ['Admin', 'Imran', 'Sohail', 'Zahid', 'Bilal'];
for (let userName of users) {
    if (userName === "Admin") {
        console.log(`Hello ${userName}, would you like to see a status report?`);
    }else{
        console.log(`Hello ${userName}, thank you for logging in again.`);
    }
}