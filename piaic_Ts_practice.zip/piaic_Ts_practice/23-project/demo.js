//  Test no 1 True;
var city = "Karachi";
if (city === "Karachi") {
    console.log(true);
}
else {
    console.log(false);
}
//  Test no 2 True;
var number = 10;
if (number === 10) {
    console.log(true);
}
else {
    console.log(false);
}
// Test no 3 True:
var myName = "Abid";
if (myName === "Abid") {
    console.log(true);
}
else {
    console.log(false);
}
// Test no 4 True:
var time = "6:pm";
if (time === "6:pm") {
    console.log(true);
}
else {
    console.log(false);
}
// Test no 5 True :
var color = "Green";
if (color === "Green") {
    console.log(true);
}
else {
    console.log(false);
}
// -- ----------------------     ...          False Conditions   ......-----------------------
//   Test no 6  False :
var num = 1000;
if (num === 2000) {
    console.log(true);
}
else {
    console.log(false);
}
//   Test no 7 False :
var country = "Pakistan";
if (country === "china") {
    console.log(true);
}
else {
    console.log(false);
}
//  Test no 8   False :
var myHobby = "coding";
if (myHobby === "cricket") {
    console.log(true);
}
else {
    console.log(false);
}
// Test no 9   False :
var door = "closed";
if (door === "open") {
    console.log(true);
}
else {
    console.log(false);
}
//  Test no 10 False :
var score = 250;
if (score > 300) {
    console.log(true);
}
else if (score > 260) {
    console.log(true);
}
else {
    console.log(false);
}
