//  Tests for equality and inequality with strings
/// Equality with String 
var pak = "Pakistan";
if (pak === "Pakistan") {
    console.log("Pakistan");
}
// InEquality with String:
var ind = "India";
if (ind === "Pakistan") {
    console.log("Pakistan");
}
else {
    console.log("India");
}
// Not Equal 
var USA = "United-State-of-America";
if (USA !== "United-Kingdom") {
    console.log("America");
}
///////////-       Tests using the lower case function
var myHome = "pakistan";
if (myHome === "Pakistan") {
    console.log("Not in UpperCase"); // not in upercase
}
else {
    console.log("Working in lower case");
}
//////
// --  Numerical tests involving equality and inequality, greater than and less than, greater than or equal to, and less than or equal to
// --  Numerical test of Equality;
var a = 20;
var b = 20;
if (a === b) {
    console.log("Yes, a is equal to b");
}
// --  Numerical test of InEquality;
var c = 30;
var d = 20;
if (c === d) {
    console.log("50");
}
else {
    console.log("No, c is not equal to d");
}
// Numerical test with Greater than:
var ab = 30;
var ba = 10;
if (ab > ba) {
    console.log("Yes, ab is greater than ba");
}
// Numerical test with Less than:
var bc = 40;
var cb = 60;
if (bc < cb) {
    console.log("Yes, bc is Less than cb");
}
// Numerical test with Greater than or Equal to :
var abc = 300;
var bca = 290;
if (abc >= bca) {
    console.log("abc is Greater than or Equal to bca");
}
// Numerical test with Less than or Equal to :
var x = 500;
var z = 1000;
if (x <= z) {
    console.log("Yes, x is less than or Equal to z");
}
////  --------------        Tests using "and" and "or" operators
//  Test with and operator:
// for End operator both conditions shoulb be true
if (20 > 10 && 100 < 200) {
    console.log("Hello I am using And Operator");
}
//  Test with OR operator:
// for End operator both conditions shoulb be true
if (200 > 300 || 20 < 30) {
    console.log("Hello I am using Or Operator");
}
///// -- -----------        Test whether an item is in a array
var inBag = ["Laptop", "Notebook", "Pen", "Water-bottle"];
if (inBag[0] == "Laptop") {
    console.log("Yes, Laptop is here");
}
/// ---------------   • Test whether an item is not in a array
if (inBag[1] == "Lunch-box") {
    console.log("Yes,here it is");
}
else {
    console.log("No it is nor here");
}
// Finding Laptop in this Array
var Arr = ["Mobile", "Laptop", "Bag"];
var item = Arr.find(search);
function search(Laptop) {
    return Laptop == 'Laptop';
}
console.log(item); // Yes, found it
// Finding Book in an Array
var Arr2 = ["Mobile", "Laptop", "Bag"];
var item2 = Arr2.find(search2);
function search2(Book) {
    return Book == 'Book';
}
console.log(item2); //  Book not found in this Array
