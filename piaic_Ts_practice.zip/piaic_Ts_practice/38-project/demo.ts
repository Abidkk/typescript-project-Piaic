function describeCity(city: string, country: string = "Pakistan"): void {
    console.log(`${city} is in ${country}.`);
  }
  
  describeCity("Karachi"); // Karachi is in Pakistan.
  describeCity("London", "United Kingdom"); // London is in United Kingdom.
  describeCity("New York", "USA"); // New York is in USA.