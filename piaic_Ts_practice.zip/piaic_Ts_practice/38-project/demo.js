function describeCity(city, country) {
    if (country === void 0) { country = "Pakistan"; }
    console.log("".concat(city, " is in ").concat(country, "."));
}
describeCity("Karachi"); // Karachi is in Pakistan.
describeCity("London", "United Kingdom"); // London is in United Kingdom.
describeCity("New York", "USA"); // New York is in USA.
